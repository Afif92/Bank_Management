<?php    
require_once('../class/autoload.php');
$Id=new AIUBID();
//echo $Id->generateAiubId(10);
 $id= $Id->generateAiubId(10);
 echo $id;

?>

