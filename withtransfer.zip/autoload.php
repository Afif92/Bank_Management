<?php 
//Author Rifat,Ahmed Habibullah
//AIUBID GENERATOR version 1.4.7
function __autoload($AIUBID) {
  require_once $AIUBID. '.php';
}


