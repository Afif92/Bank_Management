
<body>
<table>
				<tr>
		         <th colspan="2" width="200"  ><a href="Admin_Homepage.html">Admin home page</a></th>
				 <th colspan="2" width="200" ><a href="New_User.php">New User</a></th>
				 <th colspan="2" width="200"><a href="Existing_User.php">Existing User</a></th>
				 <th width="200" colspan="2"><a href="Deposit.php">Deposit</a></th>
				 <th width="200" colspan="2"><a href="Withdraw.php">Withdraw</a></th>
				 <th width="200" colspan="2"><a href="Transfer.php">Transfer</a></th>
				 <th width="200" colspan="2"><a href="Showhistory.php">Showhistory</a></th>
				 <th width="200"><a href="Logout.php">Logout</a></th>
				</tr>
			
		</table>

<center><h1><u>Users History</u></h1></center>
<table border="solid black" cellspacing="0"  width="100%">

<tr>

<th align="center">DATE</th>
<th align="center">ID</th>
<th align="center"> Type</th>
<th align="center"> Ammount</th>
</tr>
<?php
			$query="SELECT * FROM history";
			$con=mysqli_connect("localhost","root","","bank_project") or die("cannot connect");
			$result=mysqli_query($con,$query);	
			while($row=mysqli_fetch_assoc($result))
			{
				
				echo "<tr>
		         <th  align='center' >$row[date]</th>				
				 <th align='center'>$row[Id]</th>
				 <th align='center'>$row[type]</th>
				 <th align='center'>$row[ammount]</th>
				
				</tr>";
			}
	?>		

</table>

</body>
