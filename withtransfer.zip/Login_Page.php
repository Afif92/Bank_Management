<?php 
session_start();
?>

<html>
	<head>
		<title>Login</title>
	</head>	
	
	<body align="center"   >
		<table align="center">
			<tr>
			<td>
			<p><a href="index.php">Home</a>&nbsp;&nbsp;&nbsp;
			<a href="About_Us.html">About us</a>&nbsp;&nbsp;&nbsp;
			<a href="Login_Page.php">Login</a>&nbsp;&nbsp;&nbsp;
			<a href="Create_Account.php">Create Account</a></p>
			</td>
			</tr>			
		</table><br/>
	
	<center>
		<form method="post" action="login_script.php">		
			<table>
				<tr>
				<td width="200">
				<fieldset>
				<legend><b>Login</b></legend>			
				Id <br/>
				<input type="text" name="ID"/><br/>			
				Password <br/>
				<input type="password" name="PASSWORD"/><br/>			
				<hr />
				<input type="submit" value="Login" name="Login"/>
				<a href="Create_Account.php">CreateAccount</a>
				</fieldset>
				</td>
				</tr>
				
			</table>
			
			</form></center>
	</body>
</html>


			
		

 
