<html>
	<head><title>Update page</title></head>
	<body>
		<table align="right">
			<tr>
				<th colspan="2" width="200" ><a href="Existing_User.php">Home</a></th>
				<th width="200"><a href="Logout.php">Logout</a></th>
			</tr>
		</table>
	</body>	
</html>
<?php
	$id=$_GET['id'];
	$query="SELECT 	Name, FatherName, Email, DOB ,Phone, Balance,ID FROM information WHERE ID=$id";
	$con=mysqli_connect("localhost","root","","bank_project"); //or die("cannot connect");
	$result=mysqli_query($con,$query);	
	 if($row = mysqli_fetch_assoc($result)){
		echo '<form method="post">
			ID:'.$row['ID'].'
			<input type="hidden" name="ID" value="'.$row['ID'].'"/>	
			<br/>Name:<br/>
			<input name="Name" value="'.$row['Name'].'"/>
			<br/>FatherName:<br/>
			<input name="FatherName" value="'.$row['FatherName'].'"/>
			<br/>DOB:<br/>
			<input name="DOB" value="'.$row['DOB'].'"/>
			<br/>PhoneNo:<br/>
		    <input name="Phone" value="'.$row['Phone'].'"/>
			<br/>Balance<br/>
			<input name="Balance" value="'.$row['Balance'].'"/>
			<br/><br/>
			<input type="submit" value="Submit" />
		</form>';
	}
	//echo "<a href='retrieve.php'>View</a>";
?>
<?php

	if($_SERVER['REQUEST_METHOD']=="POST"){
		$id = $_POST['ID'];
		$name = $_POST['Name'];
		$fname = $_POST['FatherName'];
		$dob = $_POST['DOB'];
		$phone = $_POST['Phone'];
		$bal = $_POST['Balance'];
		
		$query = "UPDATE information SET Name='$name', FatherName='$fname', DOB='$dob',phone='$phone', Balance='$bal' WHERE id=$id";
		$con = mysqli_connect("localhost", "root", "", "bank_project");	
		$result = mysqli_query($con, $query);	
		if($result)
	{
			 echo "
            <script type=\"text/javascript\">
             alert('Sure Want to Update??');
            </script>
        ";
		echo "<br/>"."Updated"."<br/>";
		
	}
		}
		
		
	
?>